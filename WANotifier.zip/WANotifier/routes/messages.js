const express = require('express');
const { validateMessage, validatePhoneNumber } = require('../middleware/validation');
const logger = require('../utils/logger');
const { whatsappManager } = require('../whatsapp-client');

const router = express.Router();

// Send message endpoint
router.post('/send', validateMessage, async (req, res) => {
    try {
        const { phone, message } = req.body;
        
        if (!whatsappManager.isClientReady()) {
            return res.status(503).json({
                error: 'WhatsApp client is not ready',
                message: 'Please wait for WhatsApp to connect or scan QR code'
            });
        }

        const result = await whatsappManager.sendMessage(phone, message);
        
        res.json({
            success: true,
            data: result,
            message: 'Message sent successfully'
        });
        
    } catch (error) {
        logger.error('Error sending message:', error);
        
        if (error.message.includes('not registered on WhatsApp')) {
            return res.status(400).json({
                error: 'Invalid phone number',
                message: error.message
            });
        }
        
        res.status(500).json({
            error: 'Failed to send message',
            message: error.message
        });
    }
});

// Get chats endpoint
router.get('/chats', async (req, res) => {
    try {
        if (!whatsappManager.isClientReady()) {
            return res.status(503).json({
                error: 'WhatsApp client is not ready',
                message: 'Please wait for WhatsApp to connect'
            });
        }

        const chats = await whatsappManager.getChats();
        
        res.json({
            success: true,
            data: chats,
            count: chats.length
        });
        
    } catch (error) {
        logger.error('Error getting chats:', error);
        res.status(500).json({
            error: 'Failed to get chats',
            message: error.message
        });
    }
});

// Get client status endpoint
router.get('/status', (req, res) => {
    const isReady = whatsappManager.isClientReady();
    const client = whatsappManager.client;
    
    res.json({
        connected: isReady,
        info: isReady && client.info ? {
            pushname: client.info.pushname,
            phone: client.info.wid.user,
            platform: client.info.platform
        } : null,
        timestamp: new Date().toISOString()
    });
});

// Send bulk messages endpoint
router.post('/send-bulk', async (req, res) => {
    try {
        const { recipients, message } = req.body;
        
        if (!Array.isArray(recipients) || recipients.length === 0) {
            return res.status(400).json({
                error: 'Invalid recipients',
                message: 'Recipients must be a non-empty array of phone numbers'
            });
        }
        
        if (!message || message.trim().length === 0) {
            return res.status(400).json({
                error: 'Invalid message',
                message: 'Message cannot be empty'
            });
        }
        
        if (!whatsappManager.isClientReady()) {
            return res.status(503).json({
                error: 'WhatsApp client is not ready',
                message: 'Please wait for WhatsApp to connect'
            });
        }
        
        const results = [];
        const errors = [];
        
        // Send messages with delay to avoid rate limiting
        for (let i = 0; i < recipients.length; i++) {
            const phone = recipients[i];
            
            try {
                const result = await whatsappManager.sendMessage(phone, message);
                results.push({
                    phone,
                    success: true,
                    messageId: result.messageId
                });
                
                // Add delay between messages (2 seconds)
                if (i < recipients.length - 1) {
                    await new Promise(resolve => setTimeout(resolve, 2000));
                }
                
            } catch (error) {
                logger.error(`Failed to send message to ${phone}:`, error);
                errors.push({
                    phone,
                    success: false,
                    error: error.message
                });
            }
        }
        
        res.json({
            success: true,
            summary: {
                total: recipients.length,
                successful: results.length,
                failed: errors.length
            },
            results: results,
            errors: errors
        });
        
    } catch (error) {
        logger.error('Error sending bulk messages:', error);
        res.status(500).json({
            error: 'Failed to send bulk messages',
            message: error.message
        });
    }
});

module.exports = router;
