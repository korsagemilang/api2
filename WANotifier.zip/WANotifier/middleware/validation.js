const logger = require('../utils/logger');

// Validate message request
function validateMessage(req, res, next) {
    const { phone, message } = req.body;
    
    // Validate phone number
    if (!phone) {
        return res.status(400).json({
            error: 'Missing phone number',
            message: 'Phone number is required'
        });
    }
    
    if (!isValidPhoneNumber(phone)) {
        return res.status(400).json({
            error: 'Invalid phone number',
            message: 'Phone number must be in valid format (e.g., +1234567890 or 1234567890)'
        });
    }
    
    // Validate message
    if (!message) {
        return res.status(400).json({
            error: 'Missing message',
            message: 'Message content is required'
        });
    }
    
    if (typeof message !== 'string') {
        return res.status(400).json({
            error: 'Invalid message format',
            message: 'Message must be a string'
        });
    }
    
    if (message.trim().length === 0) {
        return res.status(400).json({
            error: 'Empty message',
            message: 'Message cannot be empty'
        });
    }
    
    if (message.length > 4096) {
        return res.status(400).json({
            error: 'Message too long',
            message: 'Message cannot exceed 4096 characters'
        });
    }
    
    next();
}

// Validate phone number format
function validatePhoneNumber(req, res, next) {
    const { phone } = req.params;
    
    if (!phone || !isValidPhoneNumber(phone)) {
        return res.status(400).json({
            error: 'Invalid phone number',
            message: 'Phone number must be in valid format'
        });
    }
    
    next();
}

// Helper function to validate phone number
function isValidPhoneNumber(phone) {
    if (!phone || typeof phone !== 'string') {
        return false;
    }
    
    // Remove all non-numeric characters for validation
    const cleaned = phone.replace(/\D/g, '');
    
    // Check if it's a valid length (10-15 digits)
    if (cleaned.length < 10 || cleaned.length > 15) {
        return false;
    }
    
    // Basic regex pattern for international phone numbers
    const phoneRegex = /^[\+]?[\d\s\-\(\)]{10,}$/;
    return phoneRegex.test(phone);
}

// Validate request content type
function validateContentType(req, res, next) {
    if (req.method === 'POST' || req.method === 'PUT') {
        if (!req.is('application/json')) {
            return res.status(400).json({
                error: 'Invalid content type',
                message: 'Content-Type must be application/json'
            });
        }
    }
    next();
}

// Rate limiting middleware (simple in-memory implementation)
const rateLimitMap = new Map();

function rateLimit(windowMs = 60000, maxRequests = 10) {
    return (req, res, next) => {
        const clientIp = req.ip || req.connection.remoteAddress;
        const now = Date.now();
        const windowStart = now - windowMs;
        
        // Clean old entries
        for (const [ip, requests] of rateLimitMap.entries()) {
            const filteredRequests = requests.filter(timestamp => timestamp > windowStart);
            if (filteredRequests.length === 0) {
                rateLimitMap.delete(ip);
            } else {
                rateLimitMap.set(ip, filteredRequests);
            }
        }
        
        // Check current client's requests
        const clientRequests = rateLimitMap.get(clientIp) || [];
        const recentRequests = clientRequests.filter(timestamp => timestamp > windowStart);
        
        if (recentRequests.length >= maxRequests) {
            return res.status(429).json({
                error: 'Too many requests',
                message: `Rate limit exceeded. Max ${maxRequests} requests per ${windowMs / 1000} seconds`,
                retryAfter: Math.ceil((recentRequests[0] + windowMs - now) / 1000)
            });
        }
        
        // Add current request
        recentRequests.push(now);
        rateLimitMap.set(clientIp, recentRequests);
        
        next();
    };
}

module.exports = {
    validateMessage,
    validatePhoneNumber,
    validateContentType,
    rateLimit,
    isValidPhoneNumber
};
