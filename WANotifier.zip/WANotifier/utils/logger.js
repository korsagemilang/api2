const fs = require('fs');
const path = require('path');

class Logger {
    constructor() {
        this.logDir = './logs';
        this.ensureLogDirectory();
    }

    ensureLogDirectory() {
        if (!fs.existsSync(this.logDir)) {
            fs.mkdirSync(this.logDir, { recursive: true });
        }
    }

    formatMessage(level, message, data = null) {
        const timestamp = new Date().toISOString();
        const logEntry = {
            timestamp,
            level: level.toUpperCase(),
            message
        };

        if (data) {
            logEntry.data = data;
        }

        return logEntry;
    }

    writeToFile(logEntry) {
        try {
            const logFile = path.join(this.logDir, `${new Date().toISOString().split('T')[0]}.log`);
            const logLine = JSON.stringify(logEntry) + '\n';
            fs.appendFileSync(logFile, logLine);
        } catch (error) {
            console.error('Failed to write to log file:', error);
        }
    }

    writeToConsole(logEntry) {
        const { timestamp, level, message, data } = logEntry;
        const colorMap = {
            'INFO': '\x1b[36m',    // Cyan
            'WARN': '\x1b[33m',    // Yellow
            'ERROR': '\x1b[31m',   // Red
            'DEBUG': '\x1b[35m'    // Magenta
        };
        
        const resetColor = '\x1b[0m';
        const color = colorMap[level] || '';
        
        let output = `${color}[${timestamp}] ${level}:${resetColor} ${message}`;
        
        if (data) {
            output += '\n' + JSON.stringify(data, null, 2);
        }
        
        console.log(output);
    }

    log(level, message, data = null) {
        const logEntry = this.formatMessage(level, message, data);
        
        // Write to console
        this.writeToConsole(logEntry);
        
        // Write to file
        this.writeToFile(logEntry);
    }

    info(message, data = null) {
        this.log('info', message, data);
    }

    warn(message, data = null) {
        this.log('warn', message, data);
    }

    error(message, data = null) {
        this.log('error', message, data);
    }

    debug(message, data = null) {
        if (process.env.NODE_ENV === 'development' || process.env.DEBUG === 'true') {
            this.log('debug', message, data);
        }
    }

    // Method to get recent logs
    getRecentLogs(lines = 100) {
        try {
            const logFile = path.join(this.logDir, `${new Date().toISOString().split('T')[0]}.log`);
            
            if (!fs.existsSync(logFile)) {
                return [];
            }
            
            const content = fs.readFileSync(logFile, 'utf8');
            const logLines = content.trim().split('\n').filter(line => line.length > 0);
            
            // Get the last N lines
            const recentLines = logLines.slice(-lines);
            
            return recentLines.map(line => {
                try {
                    return JSON.parse(line);
                } catch (error) {
                    return { message: line, timestamp: new Date().toISOString(), level: 'UNKNOWN' };
                }
            });
        } catch (error) {
            this.error('Failed to read log file:', error);
            return [];
        }
    }

    // Method to clear old log files
    clearOldLogs(daysToKeep = 7) {
        try {
            const files = fs.readdirSync(this.logDir);
            const cutoffDate = new Date();
            cutoffDate.setDate(cutoffDate.getDate() - daysToKeep);
            
            files.forEach(file => {
                if (file.endsWith('.log')) {
                    const filePath = path.join(this.logDir, file);
                    const stat = fs.statSync(filePath);
                    
                    if (stat.mtime < cutoffDate) {
                        fs.unlinkSync(filePath);
                        this.info(`Deleted old log file: ${file}`);
                    }
                }
            });
        } catch (error) {
            this.error('Failed to clear old logs:', error);
        }
    }
}

// Export singleton instance
const logger = new Logger();

// Clean old logs on startup
logger.clearOldLogs();

module.exports = logger;
